require('dotenv').config();
const jwt = require('jsonwebtoken');

async function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    console.log("Auth Header" + authHeader);
    const token = authHeader && authHeader.split(' ')[1]
    try {
        if (token == null) {
            return res.sendStatus(401);
        }
        else {
            jwt.verify(token, process.env.ACCESS_TOKEN, (err, response) => {
                if (err) {
                    return res.sendStatus(403);
                }
                res.locals = response;
                next();
            })
        }
    } catch (err) {
        return res.status(500).json(err);
    }

}

module.exports = { authenticateToken: authenticateToken }