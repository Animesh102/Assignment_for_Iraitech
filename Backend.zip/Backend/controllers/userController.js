const connection = require('../db');
const userSchema = require('../schema/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { findById } = require('../schema/user');
require('dotenv').config();
const signup = async (req, res, next) => {
    let data = req.body;
    let email = data.email;
    console.log("Data " + JSON.stringify(data));
    const getUser = await userSchema.findOne({ email: email });
    if (getUser) {
        console.log("Already User");
        return res.status(400).json({
            status: "Already User",
            message: "Oops you are already registered"
        })
    } else {
        let userObj = {};
        let salt = await bcrypt.genSalt(10);
        let password = data.password;
        let encryptedPassword = await bcrypt.hash(password, salt);
        userObj.firstName = data.firstName;
        userObj.lastName = data.lastName;
        userObj.email = data.email;
        userObj.phone = data.phone;
        userObj.dob = data.dob;
        userObj.address = data.address;
        userObj.pinCode = data.pinCode;
        userObj.password = encryptedPassword;
        const insertUser = await userSchema(userObj).save();
        if (insertUser) {
            return res.status(200).json({
                status: "Success",
                message: "User Added",
            })
        } else {
            return res.status(400).json({
                status: "Failed to update",
                message: "Something went wrong"
            })
        }
    }

};

const signin = async (req, res, next) => {
    try{
    let data = req.body;
    console.log("Signin Detail" + JSON.stringify(data));
    let email = data.email;
    const findUser = await userSchema.findOne({ email: email });
    if (findUser) {
        let plainPassword = data.password;
        await bcrypt.compare(plainPassword, findUser.password, function (err, hash) {
            if (hash == true) {
                const tokenToSet = jwt.sign({_id:findUser._id},process.env.TOKEN_KEY,{expiresIn:"2h"});
                console.log("UserID"+findUser._id);
                console.log("Token to send :"+tokenToSet);
                 userSchema.findByIdAndUpdate(findUser._id, {token: tokenToSet},function(err,docs){
                    if(err){
                        console.log("err");
                    }else{
                        try{
                            const updatedUser = userSchema.findById(findUser._id,function(err,dataToShow){
                                if(err) throw error;
                                res.status(200).json(dataToShow);
                            });
                          
                        }catch(err){
                            console.log(err);
                        }            
                    } 
                });      
            } else {
                return res.status(400).json({
                    status: "Hashing Issue",
                    message: "Something went wrong while hasing"
                })
            }
        });
    } else {
        return res.status(400).json({
            status: "Email id not Registered",
            message: "No user with such id is available"
        })
    }
}catch(error){
    console.log(error)
}
};

module.exports = { signup, signin };
