const connection = require('../db');
const userSchema = require('../schema/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const config = process.env;
const otpGenerator = require('otp-generator');
const auth = require('../middleware/auth');
const dashboard = async (req, res, next) => {

};

const profile = async (req, res, next) => {
    const value = req.user;
    const user = value._id;
    try {
        const userGenuine = userSchema.findById(user, function (err, dataToShow) {
            if (err) throw error;
            res.status(200).json(dataToShow);
        });
    } catch (err) {
        res.status(400);
    }
};

const profileUpdate = async (req, res, next) => {
    const data = req.body;
    const value = req.user;
    const user = value._id;
    try {
        const userGenuine = userSchema.findById(user, function (err, dataToShow) {
            if (err) {
                throw error;
            } else {
                const updatedUser = userSchema.findByIdAndUpdate(user, data, function (err, success) {
                    if (err) {
                        return res.status(400).json({
                            status: "Failed to Update",
                            message: "Something went wrong"
                        })
                    } else {
                        console.log(success);
                        return res.status(200).json({
                            status: "Success",
                            message: "Updated Profile Successfully"
                        })
                    }
                })
            }

        });
    } catch (err) {
        res.status(400);
    }
}

const passwordUpdate = async (req, res, next) => {
    const value = req.user;
    const user = value._id;
    let salt = await bcrypt.genSalt(10);
    let password = req.body.password;
    let encryptedPassword = await bcrypt.hash(password, salt);
    try {
        const userGenuine = await userSchema.findById(user, function (err, dataToShow) {
            if (err) {
                throw error;
            } else {
                try {
                    userSchema.findByIdAndUpdate(user, { password: encryptedPassword }, function (err, success) {
                        if (err) {
                            return res.status(400).json({
                                status: "Failed to Update",
                                message: "Something went wrong"
                            })
                        } else {
                            console.log(success);
                            return res.status(200).json({
                                status: "Success",
                                message: "Updated Profile Successfully"
                            })
                        }
                    })
                } catch (err) {
                    console.log("TRY CATCH ERROR+" + err);
                }
            }
        });
    } catch (err) {
        res.status(400);
    }
}

const passwordResetOTP = async (req, res, next) => {
    const data = req.body;
    const isvalid = await userSchema.findOne(data);
    if (isvalid) {
        let otpGenerated = await otpGenerator.generate(6, { upperCaseAlphabets: true, specialChars: false });
        userSchema.findByIdAndUpdate(isvalid._id, { otp: otpGenerated }, function (err, success) {
            if (err) {
                return res.status(400).json({
                    status: "Failed",
                    message: "Something went wrong"
                })
            } else {
                console.log("SUCCESS : " + success);
                return res.status(200).json({
                    status: "Success",
                    message: "OTP sent"
                })
            }
        })
    } else {
        return res.status(400).json({
            status: "Failed",
            message: "Unauthorized User"
        })
    }
}

const verifyOTP = async (req, res, next) => {
    const data = req.body;
    const value = req.user;
    const user = value._id;
    const otpInput = data.otp;
    const isvalid = await userSchema.findOne({ email: data.email });
    if (isvalid) {
        const setOtp = await userSchema.findOne({ otp: data.otpInput });
        if (setOtp) {
            let salt = await bcrypt.genSalt(10);
            let password = req.body.password;
            let encryptedPassword = await bcrypt.hash(password, salt);
            try {
                const userGenuine = await userSchema.findById(user, function (err, dataToShow) {
                    if (err) {
                        throw error;
                    } else {
                        try {
                            userSchema.findByIdAndUpdate(user, { password: encryptedPassword }, function (err, success) {
                                if (err) {
                                    return res.status(400).json({
                                        status: "Failed to Update",
                                        message: "Something went wrong"
                                    })
                                } else {
                                    console.log(success);
                                    return res.status(200).json({
                                        status: "Success",
                                        message: "Updated Profile Successfully"
                                    })
                                }
                            })
                        } catch (err) {
                            console.log("TRY CATCH ERROR+" + err);
                        }
                    }
                });
            } catch (err) {
                res.status(400);
            }
        } else {
            return res.status(400).json({
                status: "Wrong OTP",
                message: "Entered wrong OTP"
            })
        }
    }
}

module.exports = { dashboard, profile, profileUpdate, passwordUpdate, passwordResetOTP, verifyOTP };
