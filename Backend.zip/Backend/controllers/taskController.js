const taskSchema = require('../schema/task');
const userSchema = require('../schema/user');

const taskAdd = async (req, res, next) => {
    const data = req.body;
    const subject = data.subject;
    const description = data.description;
    const priority = data.priority;
    const userDetail = req.user;
    try {
        const addTask = await taskSchema({ uid: userDetail._id, subject: subject, description: description, priority: priority }).save();
        if (addTask) {
            return res.status(200).json({
                status: "Success",
                message: "Task Added Successfully"
            })
        } else {
            return res.status(400).json({
                status: "Failed",
                message: "Something went wrong while adding Task"
            })
        }
    } catch (err) {
        console.log(err);
    }
}

const taskView = async (req, res, next) => {
    const userDetail = req.user;
    try {
        const task = await taskSchema.find({uid:userDetail._id});
        if (task) {
            return res.status(200).json({
                status: "Success",
                message: "Task Recieved Successfully",
                data: task
            })
        } else {
            return res.status(400).json({
                status: "Failed",
                message: "Something went wrong while showing task"
            })
        }
    } catch (err) {
        console.log(err);
    }
}

module.exports = { taskAdd, taskView };