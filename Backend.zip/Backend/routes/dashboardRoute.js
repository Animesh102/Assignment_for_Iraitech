const express = require('express');
const connection = require('../db');
require('dotenv').config();
const router = express.Router();
const auth = require('../middleware/auth');
const dashboardController = require('../controllers/dashboardController');

router.post('/profile', auth, dashboardController.profile);
router.post('/dashboard', auth, dashboardController.dashboard);
router.post('/profileUpdate', auth, dashboardController.profileUpdate);
router.post('/passwordUpdate', auth, dashboardController.passwordUpdate);
router.post('/passwordResetOTP',auth, dashboardController.passwordResetOTP);
router.post('/verifyOTP', auth, dashboardController.verifyOTP);

module.exports = router;