const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');

router.post('/taskAdd', taskController.taskAdd);
router.post('/taskView', taskController.taskView);

module.exports = router;