const express = require('express');
var cors = require('cors');
const connection = require('./db');
const userRoute = require('./routes/userRoute');
const dashboardRoute = require('./routes/dashboardRoute');
const taskRoute = require('./routes/taskRoute');
const app = express();
const auth = require('./middleware/auth');
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/', (req, res) => res.send('Api Hunter'));
module.exports = app;
require('dotenv').config();
app.listen(process.env.PORT, () => {
    console.log(`App listening on port ` + process.env.PORT)
})

app.use('/user', userRoute);
app.use('/api', auth, dashboardRoute);
app.use('/api/taskmanager', auth, taskRoute);