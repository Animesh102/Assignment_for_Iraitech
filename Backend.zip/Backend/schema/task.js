const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
    uid: {
        type: String,
    },
    subject: {
        type: String,
    },
    description: {
        type: String,
    },
    priority: {
        type: String,
    },
}, {timestamps: true});

module.exports = mongoose.model('task',taskSchema,'task');